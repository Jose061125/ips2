
from flask import render_template, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required
from . import auth_bp
from ..forms import LoginForm, RegistrationForm

# --- Inyección de Dependencias --- #
from ..services.user_service import UserService
from ..adapters.sql_user_repository import SqlAlchemyUserRepository

user_repository = SqlAlchemyUserRepository()
user_service = UserService(user_repository)
# --------------------------------- #

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        success, message = user_service.register_user(
            username=form.username.data,
            password=form.password.data
        )
        flash(message)
        if success:
            return redirect(url_for('auth.login'))
        else:
            return redirect(url_for('auth.register'))
    return render_template('register.html', form=form)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        # La vista delega la lógica de autenticación al servicio del núcleo
        user = user_service.login(
            username=form.username.data, 
            password=form.password.data
        )
        
        if user is None:
            flash('Nombre de usuario o contraseña inválidos')
            return redirect(url_for('auth.login'))
        
        # Flask-Login sigue manejando la sesión del usuario
        login_user(user)
        flash('¡Has iniciado sesión con éxito!')
        return redirect(url_for('main.index'))
        
    return render_template('login.html', form=form)

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Has cerrado la sesión.')
    return redirect(url_for('main.index'))
