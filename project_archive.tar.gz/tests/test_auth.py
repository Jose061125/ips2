def test_register_get(client):
    """Test that the registration page loads correctly."""
    response = client.get("/auth/register")
    assert response.status_code == 200
    assert b'Register' in response.data

def test_register_post(client):
    """Test that a new user can register."""
    response = client.post("/auth/register", data={
        "username": "testuser",
        "password": "password",
        "confirm_password": "password"
    }, follow_redirects=True)
    assert response.status_code == 200
    # Encode the non-ASCII string to bytes for the assertion
    assert '¡Felicidades, ahora eres un usuario registrado!'.encode('utf-8') in response.data

def test_login_get(client):
    """Test that the login page loads correctly."""
    response = client.get("/auth/login")
    assert response.status_code == 200
    assert b'Login' in response.data

def test_login_post(client):
    """Test that a registered user can log in."""
    client.post("/auth/register", data={
        "username": "testuser",
        "password": "password",
        "confirm_password": "password"
    })
    response = client.post("/auth/login", data={
        "username": "testuser",
        "password": "password"
    }, follow_redirects=True)
    assert response.status_code == 200
    assert b'Hi, testuser!' in response.data
    assert '¡Has iniciado sesión con éxito!'.encode('utf-8') in response.data

def test_login_post_invalid_user(client):
    """Test that a non-existent user cannot log in."""
    response = client.post("/auth/login", data={
        "username": "nonexistentuser",
        "password": "password"
    }, follow_redirects=True)
    assert response.status_code == 200
    # Encode the non-ASCII string to bytes
    assert 'Nombre de usuario o contraseña inválidos'.encode('utf-8') in response.data

def test_logout(client):
    """Test that a logged in user can log out."""
    client.post("/auth/register", data={
        "username": "testuser",
        "password": "password",
        "confirm_password": "password"
    })
    client.post("/auth/login", data={
        "username": "testuser",
        "password": "password"
    }, follow_redirects=True)

    response = client.get("/auth/logout", follow_redirects=True)
    assert response.status_code == 200
    assert b'Hi, testuser!' not in response.data
    # Encode the non-ASCII string to bytes
    assert 'Has cerrado la sesión.'.encode('utf-8') in response.data
